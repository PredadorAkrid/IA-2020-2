﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Actuadores : MonoBehaviour
{
    private Rigidbody rb; // Componente para simular acciones físicas realistas
    public Bateria bateria; // Componente adicional (script) que representa la batería
    private Sensores sensor; // Componente adicional (script) para obtener información de los sensores
    private float upForce; // Indica la fuerza de elevación del dron
    private float movementForwardSpeed = 250.0f; // Escalar para indicar fuerza de movimiento frontal
    private float wantedYRotation; // Auxiliar para el cálculo de rotación
    private float currentYRotation; // Auxiliar para el cálculo de rotación
    private float rotateAmountByKeys = 2.5f; // Auxiliar para el cálculo de rotación
    private float rotationYVelocity; // Escalar (calculado) para indicar velocidad de rotación
    private float sideMovementAmount = 2500.0f;
    static int x = 0;
    static int y = 0; 
    static int z = 0;
    static int w = 0;
    public float CargaX;
    public float CargaY;
    public float CargaZ;
    public float lastX;
    public float lastY;
    public float lastZ;
    private Vector3 baseCarga;
    // Asignaciones de componentes
    void Start(){
        rb = GetComponent<Rigidbody>();
        sensor = GetComponent<Sensores>();
        bateria = GameObject.Find("Bateria").gameObject.GetComponent<Bateria>();
        baseCarga = GameObject.FindGameObjectWithTag("BaseDeCarga").transform.position;

        CargaX = bateria.transform.position.x;
        CargaY = bateria.transform.position.y;
        CargaZ = bateria.transform.position.z;
        lastX = rb.transform.position.x;
        lastY = rb.transform.position.y;
        lastZ = rb.transform.position.z;
    }

    // ========================================
    // A partir de aqui, todos los métodos definidos son públicos, la intención
    // es que serán usados por otro componente (Controlador)

    public void Ascender(){
        upForce = 190;
        rb.AddRelativeForce(Vector3.up * upForce);
    }

    public void Descender(){
        upForce = 10;
        rb.AddRelativeForce(Vector3.up * upForce);
    }

    public void Flotar(){
        upForce = 98.1f;
        rb.AddRelativeForce(Vector3.up * upForce);
    }

    public void Adelante(){
        rb.AddRelativeForce(Vector3.forward * movementForwardSpeed);
    }

    public void Atras(){
        rb.AddRelativeForce(Vector3.back * movementForwardSpeed);
    }

    public void GirarDerecha(){
        wantedYRotation += rotateAmountByKeys;
        currentYRotation = Mathf.SmoothDamp(currentYRotation, wantedYRotation, ref rotationYVelocity, 0.25f);
        rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, currentYRotation, rb.rotation.z));
    }

    public void GirarIzquierda(){
        wantedYRotation -= rotateAmountByKeys;
        currentYRotation = Mathf.SmoothDamp(currentYRotation, wantedYRotation, ref rotationYVelocity, 0.25f);
        rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, currentYRotation, rb.rotation.z));
    }

    public void Derecha(){
        rb.AddRelativeForce(Vector3.right * sideMovementAmount);
    }

    public void Izquierda(){
        rb.AddRelativeForce(Vector3.left * sideMovementAmount);
    }

    public void Detener(){
        rb.velocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
    }


    public void CargarBateria(){
        bateria.Cargar();
        
    }
    private bool paredOeste = false;
    public bool HayPared()
    {
        
        return ((sensor.ParedNorte()) || (sensor.ParedSur()) || (sensor.ParedEste()));
    }
    public bool HayParedOeste()
    {
        this.paredOeste = false;
        if (sensor.ParedOeste())
        {
            this.paredOeste = true;
            Girar180();
            return true;
        }
        return false;
    }


    public void Girar180()
    {
        paredOeste = false;
        if (sensor.ParedNorte())
        {
            rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, 90.0f, rb.rotation.z));
            Detener();
        }
        if (sensor.ParedSur())
        {
            rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, 270.0f, rb.rotation.z));
            Detener();
        }
        if (sensor.ParedEste())
        {
            rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, 180.0f, rb.rotation.z));
            Detener();
        }

        if (sensor.ParedOeste())
        {
            rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, 0f, rb.rotation.z));
            Detener();
        }

    }

    public bool getParedOeste()
    {
        return this.paredOeste;
    }
    // Setters de las últimas coordenadas
    public void setLastX()
    {
        this.lastX = rb.transform.position.x;
    }

    public void setLastY()
    {
        this.lastY = rb.transform.position.y;
    }

    public void setLastZ()
    {
        this.lastZ = rb.transform.position.z;
    }

    // Getters de las últimas coordenadas
    public float getLastX()
    {
        return this.lastX;
    }

    public float getLastY()
    {
        return this.lastY;
    }

    public float getLastZ()
    {
        return this.lastZ;
    }
    // Getters de las coordenadas del centro de carga
    public float getCargaX()
    {
        return this.baseCarga.x;
    }

    public float getCargaY()
    {
        return this.baseCarga.y;
    }

    public float getCargaZ()
    {
        return this.baseCarga.z;
    }
    

    // Método de transporte a las coordenadas dadas.
    public void goTo(float x, float y, float z)
    {
        
        rb.MovePosition((new Vector3(x, y, z)));

    }
}
