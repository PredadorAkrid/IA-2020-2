﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Ejemplo de un comportamiento automático para el agente (basado en modelos)
public class ComportamientoAutomatico : MonoBehaviour
{

	private Sensores sensor;
	private Actuadores actuador;
	private Rigidbody rb;

	private enum Percepcion { NoParedCerca = 0, ParedCerca = 1, EdificioCerca=2, Obstaculo = 3}; // Lista predefinida de posibles percepciones con los sensores
	private enum Estado { Avanzar = 0, Detenerse = 1, Girar = 2, Arriba = 3, Derecha = 4}; // Lista de estados para la maquina de estados y tabla de transiciones
	private Estado estadoActual;
	private Percepcion percepcionActual;
	public int tiempo = 5;
	public bool cargando;

	void Start()
	{
		sensor = GetComponent<Sensores>();
		actuador = GetComponent<Actuadores>();
		estadoActual = Estado.Avanzar;
		percepcionActual = Percepcion.ParedCerca;
		rb = GetComponent<Rigidbody>();
		cargando = false;
		

	}
	public Transform other;
	float tempx, tempy, tempz;
	int primeraIteracion = 1;
	void FixedUpdate()
	{
		
		if (sensor.Bateria() < actuador.bateria.bateriaMinima){	
			if(primeraIteracion == 1)
			{
				Debug.Log("Caso 1");
				actuador.setLastX();
				actuador.setLastY();
				actuador.setLastZ();
				tempx = actuador.getLastX();
				tempy = actuador.getLastY();
				tempz = actuador.getLastZ();
				actuador.goTo(16.16f, 0.86f, -12.38f);
				primeraIteracion += 1;
			}
			else
			{
				Debug.Log("Caso 2");
				actuador.Detener();
				
				actuador.goTo(actuador.getCargaX(), actuador.getCargaY(), actuador.getCargaZ());
				actuador.bateria.Cargar();
				primeraIteracion += 1;
				actuador.goTo(tempx, tempy, tempz);
			}								

		

		}
		else if (sensor.Bateria()  > 10 && sensor.Bateria() <= 40) {
			this.primeraIteracion = 1;
		}

		else{
			
			//Debug.Log("Bateria x y z: " + actuador.getCargaX() + " " + actuador.getCargaY() + " " + actuador.getCargaZ() + " ");
			percepcionActual = PercibirMundo();
			//Debug.Log(estadoActual);
			estadoActual = TablaDeTransicion(estadoActual, percepcionActual);
			AplicarEstado(estadoActual);
			actuador.setLastX();
			actuador.setLastY();
			actuador.setLastZ();
			return;			

		}




	}
	
	// A partir de este punto se representa un agente basado en modelos.
	// La idea es similar a crear una máquina de estados finita donde se hacen las siguientes consideraciones:
	// - El alfabeto es un conjunto predefinido de percepciones hechas con sensores del agente
	// - El conjunto de estados representa un conjunto de métodos con acciones del agente
	// - La función de transición es un método
	// - El estado inicial se inicializa en Start()
	// - El estado final es opcional (pero recomendable de indicar)

	// Tabla de transición que representa el conjunto de reglas
	// -----------------------------------------------
	// | Estado\Percepcion | paredCerca | !paredCerca |
	// |-------------------|------------|-------------|
	// | Avanzar           | Detenerse  | Avanzar     |
	// |-------------------|------------|-------------|
	// | Detenerse         | Detenerse  | Detenerse   |
	// ------------------------------------------------
	Estado TablaDeTransicion(Estado estado, Percepcion percepcion)
	{
		switch (estado)
		{
			case Estado.Avanzar:
				switch (percepcion)
				{
					case Percepcion.ParedCerca:
						estado = Estado.Girar;
						break;
					case Percepcion.NoParedCerca:
						estado = Estado.Avanzar;
						break;
					case Percepcion.EdificioCerca:
						estado = Estado.Arriba;
						break;
					case Percepcion.Obstaculo:
						estado = Estado.Derecha;
						break;
				}
				break;
				case Estado.Detenerse:
					switch (percepcion)
					{
						case Percepcion.ParedCerca:
							estado = Estado.Detenerse;
							break;
						case Percepcion.NoParedCerca:
							estado = Estado.Avanzar;
							break;
						case Percepcion.Obstaculo:
							estado = Estado.Derecha;
							break;
					case Percepcion.EdificioCerca:
						estado = Estado.Arriba;
						break;
				}
					break;
				case Estado.Girar:
						switch (percepcion)
						{
							case Percepcion.ParedCerca:
								estado = Estado.Girar;
								break;
							case Percepcion.NoParedCerca:
								estado = Estado.Avanzar;
								break;
							case Percepcion.EdificioCerca:
								estado = Estado.Detenerse;
								break;
							case Percepcion.Obstaculo:
								estado = Estado.Derecha;
								break;


				}
						break;
			case Estado.Arriba:
				switch (percepcion)
				{
					case Percepcion.ParedCerca:
						estado = Estado.Girar;
						break;
					case Percepcion.NoParedCerca:
						estado = Estado.Detenerse;
						break;
					case Percepcion.EdificioCerca:
						estado = Estado.Arriba;
						break;
					case Percepcion.Obstaculo:
						estado = Estado.Detenerse;
						break;


				}
				break;
			case Estado.Derecha:
				switch (percepcion)
				{
					case Percepcion.ParedCerca:
						estado = Estado.Girar;
						break;
					case Percepcion.NoParedCerca:
						estado = Estado.Avanzar;
						break;
					case Percepcion.EdificioCerca:
						estado = Estado.Detenerse;
						break;
					case Percepcion.Obstaculo:
						estado = Estado.Derecha;
						break;


				}
				break;
		}
		return estado;
	}

	// Representación de los ESTADOS como métodos

	// El estado AVANZAR significa moverse hacia adelante siempre.
	void Avanzar()
	{
		actuador.Flotar();
		actuador.Adelante();
	}
	// El estado DETENERSE representa mantenerse en el mismo punto
	void Detenerse()
	{
		actuador.Flotar();
		actuador.Detener();
	}
	     public float rotateSpeed = 150f;

	void Girar()
	{
		actuador.Flotar();
		//transform.Rotate(Vector3.up * 50.0f * Time.deltaTime);
		actuador.Girar180();
		//transform.Rotate(new Vector3(0, 180f, 0) * (Time.deltaTime + 0.1f));
		
		//transform.rotation *= Quaternion.Euler(0, 90, 0);
		//transform.Translate(Vector3.right * 10f * Time.deltaTime);
		//transform.rotation = Quaternion.Euler(0,-360f *Time.deltaTime, 0);

		actuador.Detener();
	}

	void Derecha()
	{
		actuador.Flotar();
		//transform.Rotate(Vector3.up * 50.0f * Time.deltaTime);
		rb.rotation = Quaternion.Euler(new Vector3(rb.rotation.x, 90.0f, rb.rotation.z));
		//transform.Rotate(new Vector3(0, 180f, 0) * (Time.deltaTime + 0.1f));

		//transform.rotation *= Quaternion.Euler(0, 90, 0);
		//transform.Translate(Vector3.right * 10f * Time.deltaTime);
		//transform.rotation = Quaternion.Euler(0,-360f *Time.deltaTime, 0);

		actuador.Detener();
	}
	

	void Arriba()
	{
		actuador.Flotar();
		//transform.Rotate(Vector3.up * 50.0f * Time.deltaTime);
		actuador.Ascender();
		actuador.Detener();
	}

	// Usar sensores para determinar el tipo de percepción actual
	Percepcion PercibirMundo()
	{
		Percepcion percepcionActual = Percepcion.NoParedCerca;
		if (sensor.HayPared())
		{
			percepcionActual = Percepcion.ParedCerca;
		}
			
		else if (sensor.FrenteAEdificio())
		{
			percepcionActual = Percepcion.EdificioCerca;
		}else if (sensor.TocandoObstaculo())
		{
			percepcionActual = Percepcion.Obstaculo;
		}
		else
			percepcionActual = Percepcion.NoParedCerca;
		Debug.Log(percepcionActual);
		return percepcionActual;
	}

	// Aplicar el estado actual, i.e, mandar a llamar al método del estado dado como parámetro
	void AplicarEstado(Estado estado)
	{
		switch (estado)
		{
			case Estado.Avanzar:
				Avanzar();
				break;
			case Estado.Detenerse:
				Detenerse();
				break;
			case Estado.Girar:
				Girar();
				break;
			case Estado.Arriba:
				Arriba();
				break;
			case Estado.Derecha:
				Derecha();
				setPercepcion();
				break;
			default:
				Detenerse();
				break;
		}
	}

	public void setPercepcion()
	{
		percepcionActual = Percepcion.NoParedCerca;
		estadoActual = Estado.Avanzar;
		estadoActual = TablaDeTransicion(estadoActual, percepcionActual);
		AplicarEstado(estadoActual);
	}

}

