﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sensores : MonoBehaviour
{
    private Radar radar; // Componente auxiliar (script) para utilizar radar esférico
    private Rayo rayo; // Componente auxiliar (script) para utilizar rayo lineal
    private Bateria bateria; // Componente adicional (script) que representa la batería
    private Actuadores actuador; // Componente adicional (script) para obtener información de los ac
    private GameObject basura; // Auxiliar para guardar referencia al objeto
    public GameObject estacionDeCarga;

    private bool tocandoPared; // Bandera auxiliar para mantener el estado en caso de tocar pared
    private bool cercaPared; // Bandera auxiliar para mantener el estado en caso de estar cerca de una pared
    private bool frentePared; // Bandera auxiliar para retomar el estado en caso de estar frente a una pared
    private bool tocandoBasura; // Bandera auxiliar para mantener el estado en caso de tocar basura
    private bool cercaBasura; // Bandera auxiliar para mantener el estado en caso de estar cerca de una basura
    private bool frenteEdificio; 
    private bool tocandoEdificio;
    private bool tocandoElementoOculto;
    private bool tocandoBaseCarga;

    private bool tocandoParedNorte;
    private bool tocandoParedSur;
    private bool tocandoParedEste;
    private bool tocandoParedOeste;
    private bool frenteParedNorte;
    private bool frenteParedSur;
    private bool frenteParedEste;
    private bool frenteParedOeste;

    // Asignaciones de componentes
    void Start(){
        radar = GameObject.Find("Radar").gameObject.GetComponent<Radar>();
        rayo = GameObject.Find("Rayo").gameObject.GetComponent<Rayo>();
        bateria = GameObject.Find("Bateria").gameObject.GetComponent<Bateria>();
        actuador = GetComponent<Actuadores>();
        tocandoBaseCarga = false;
    }

    void Update(){
        /*cercaPared = radar.CercaDePared();
         cercaBasura = radar.CercaDeBasura();
        */
        /*frenteParedNorte = rayo.FrenteAPared();
        frenteParedSur = rayo.FrenteAPared();
        frenteParedEste = rayo.FrenteAParedoEste();
        frenteParedOeste = rayo.FrenteAParedOeste();
        */
        frenteEdificio = rayo.FrenteAEdificio();
      
    }

    // ========================================
    // Los siguientes métodos permiten la detección de eventos de colisión
    // que junto con etiquetas de los objetos permiten identificar los elementos
    // La mayoría de los métodos es para asignar banderas/variables de estado.

    void OnCollisionEnter(Collision other){
        /*if(other.gameObject.CompareTag("Pared")){
            tocandoPared = true;
        }*/
        if (other.gameObject.CompareTag("ParedNorte"))
            tocandoParedNorte = true;
        if (other.gameObject.CompareTag("ParedSur"))
            tocandoParedSur = true;
        if (other.gameObject.CompareTag("ParedEste"))
            tocandoParedEste = true;
        if (other.gameObject.CompareTag("ParedOeste"))
            tocandoParedOeste = true;
        if (other.gameObject.CompareTag("Edificio"))
        {
            tocandoEdificio = true;
        }
        if (other.gameObject.CompareTag("ObstaculoInvisible"))
            tocandoElementoOculto = true;
        if (other.gameObject.CompareTag("BaseDeCarga"))
        {
            tocandoBaseCarga = true;
        }
    }

    void OnCollisionStay(Collision other){
        /*if(other.gameObject.CompareTag("Pared")){
            tocandoPared = true;
        }*/
        if (other.gameObject.CompareTag("ParedNorte"))
            tocandoParedNorte = true;
        if (other.gameObject.CompareTag("ParedSur"))
            tocandoParedSur = true;
        if (other.gameObject.CompareTag("ParedEste"))
            tocandoParedEste = true;
        if (other.gameObject.CompareTag("ParedOeste"))
            tocandoParedOeste = true;
        if (other.gameObject.CompareTag("BaseDeCarga")){
            actuador.CargarBateria();
        }
        if (other.gameObject.CompareTag("Edificio"))
        {
            tocandoEdificio = true;
        }
        if (other.gameObject.CompareTag("ObstaculoInvisible"))
        {
            tocandoElementoOculto = true;
        }
    }

    void OnCollisionExit(Collision other){
        /*if(other.gameObject.CompareTag("Pared")){
            tocandoPared = false;
        }*/
        if (other.gameObject.CompareTag("ParedNorte"))
            tocandoParedNorte = false;
        if (other.gameObject.CompareTag("ParedSur"))
            tocandoParedSur = false;
        if (other.gameObject.CompareTag("ParedEste"))
            tocandoParedEste = false;
        if (other.gameObject.CompareTag("ParedOeste"))
            tocandoParedOeste = false;
        if (other.gameObject.CompareTag("Edificio"))
        {
            tocandoEdificio = false;
        }
        if (other.gameObject.CompareTag("ObstaculoInvisible"))
        {
            tocandoElementoOculto = false;
        }
        //if (other.gameObject.CompareTag("BaseDeCarga"))
        //{
        //    actuador.goTo(20f, 20f, 20f);
        //}
    }

    void OnTriggerEnter(Collider other){
        if(other.gameObject.CompareTag("Basura")){
            tocandoBasura = true;
            basura = other.gameObject;
        }
    }

    void OnTriggerStay(Collider other){
        if(other.gameObject.CompareTag("Basura")){
            tocandoBasura = true;
            basura = other.gameObject;
        }
    }

    void OnTriggerExit(Collider other){
        if(other.gameObject.CompareTag("Basura")){
            tocandoBasura = false;
        }
    }

    // ========================================
    // Los siguientes métodos definidos son públicos, la intención
    // es que serán usados por otro componente (Controlador)

    public bool TocandoPared(){
        return tocandoPared;
    }

    public bool TocandoObstaculo()
    {
        return tocandoElementoOculto;
    }

    public bool CercaDeObstaculo()
    {
        return radar.CercaDeObstaculo();
    }

    public bool CercaDePared(){
        return radar.CercaDePared();
    }

    public bool FrenteAPared(){
        return rayo.FrenteAPared();
    }

    public bool TocandoBasura(){
        return tocandoBasura;
    }
    public bool TocandoEdificio()
    {
        return tocandoEdificio;
    }
    public bool FrenteAEdificio()
    {
        return frenteEdificio;
    }
    public bool CercaDeBasura(){
        return radar.CercaDeBasura();
    }

    public float Bateria(){
        return bateria.NivelDeBateria();
    }
    public bool getBaseCarga()
    {
        return tocandoBaseCarga;
    }

    // Algunos otros métodos auxiliares que pueden ser de apoyo

    public GameObject GetBasura(){
        return basura;
    }

    public Vector3 Ubicacion(){
        return transform.position;
    }

    public void SetTocandoBasura(bool value){
        tocandoBasura = value;
    }

    public void SetCercaDeBasura(bool value){
        radar.setCercaDeBasura(value);
    }
    public bool ParedNorte()
    {
        return rayo.FrenteAParedNorte();
    }
    public bool ParedSur()

    {
        return rayo.FrenteAParedSur();
    }
    public bool ParedEste()
    {
        return rayo.FrenteAParedEste();
    }
    public bool ParedOeste()
    {
        return rayo.FrenteAParedOeste();
    }
    public bool HayPared()
    {
        return ((this.ParedNorte()) || (this.ParedSur()) || (this.ParedEste()) || (this.ParedOeste()));
    }
    public void LimpiaGiro()
    {
        radar.setCercaDeObstaculo(false);
    }
}
