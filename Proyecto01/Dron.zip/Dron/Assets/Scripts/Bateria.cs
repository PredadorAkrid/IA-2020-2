﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Componente auxiliar que modela el comportamiento de una bateria interna
// Dicha batería se descarga constantemente a menos que se utilize un método para recargar
public class Bateria : MonoBehaviour
{
    public float bateriaMinima = 10; // Mínimo número que puede alcanzar la batería
    public float bateria = 10; // Esta cifra es equivalente a los segundos activos de la batería
    public float capacidadMaximaBateria; // Indica la capacidad máxima de la batería
    public float velocidadDeCarga = 100; // Escalar para multiplicar la velocidad de carga de la batería
    public bool cargando = false;

    void Update(){
        if (bateria >= 10) // esto evita que la batería sea negativa
            bateria = bateria -  10;
        Debug.Log("Batería: " + bateria);
    }

    // ========================================
    // Métodos públicos que podrán ser utilizados por otros componentes (scripts):
    public void Cargar(){
        
            this.bateria  = 10000;
        
    }

    public float NivelDeBateria(){
        return bateria;
    }
}
